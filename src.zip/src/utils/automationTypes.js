

const automationTypes = ['reply-comment', 'dm-comment', 'blend-comment'];



export {automationTypes}