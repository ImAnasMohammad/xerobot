import Main from "./Main"


const page = () => {
  return (
    <Main/>
  )
}

export default page