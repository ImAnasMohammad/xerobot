

import { success } from "./webhookResponse";



const handleStoryInsights = (data)=>{
    console.log("handle Story Insights",data);
    return success();
}

export default handleStoryInsights;