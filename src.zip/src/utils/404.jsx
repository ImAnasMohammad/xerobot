import { Image } from '@chakra-ui/react'
import React from 'react'

const PageNotFound = () => {
  return (
    <Image src='./404.svg'/>
  )
}

export default PageNotFound