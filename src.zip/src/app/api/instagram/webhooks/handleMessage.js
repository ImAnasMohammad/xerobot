import { success } from "./webhookResponse";



const handleMessage = (data)=>{
    return success();
}

export default handleMessage;