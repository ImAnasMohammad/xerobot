import React from 'react'

const PageUnderManagement = () => {
  return (
    <div>PageUnderManagement</div>
  )
}

export default PageUnderManagement